
# IP TO COUNTRY

from google.appengine.api import memcache
import sys
import os

def convert(ip=False):
    if not ip:
        ip = os.environ['REMOTE_ADDR']
    country = memcache.get("ip_%s" % ip)
    if country is not None:
        return country
    numbers = ip.split(".")
    sys.path.append(os.path.dirname(__file__))
    r = __import__("ip%s" % numbers[0])
    code=(int(numbers[0]) * 16777216) + (int(numbers[1]) * 65536) + (int(numbers[2]) * 256) + (int(numbers[3]))   
    for z in r.ranges:
        if int(z)<=code and int(r.ranges[z][0])>=code:
            country = r.ranges[z][1]
            if country == "CS" or country == "YU":
                country = "RS"
     
            memcache.set("ip_%s" % ip, country, 3600*24*60)
            return country
    memcache.set("ip_%s" % ip, "XX", 3600*24*60)
    return "XX"